import React, { useState } from 'react';
import { ViewState } from './types';
import { DataProvider } from './context/DataContext';
import BottomNav from './components/BottomNav';
import PrayerDisplay from './features/PrayerDisplay';
import AnnouncementsList from './features/AnnouncementsList';
import EventsCalendar from './features/EventsCalendar';
import DonationScreen from './features/DonationScreen';
import AdminPortal from './features/AdminPortal';

// Component that needs access to context must be inside Provider, 
// so we create a MainContent wrapper
const MainContent = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);

  const renderContent = () => {
    switch (currentView) {
      case ViewState.HOME:
        return <PrayerDisplay onNavigate={setCurrentView} />;
      case ViewState.ANNOUNCEMENTS:
        return <AnnouncementsList />;
      case ViewState.EVENTS:
        return <EventsCalendar />;
      case ViewState.DONATE:
        return <DonationScreen />;
      case ViewState.ADMIN:
        return <AdminPortal onNavigate={setCurrentView} />;
      default:
        return <PrayerDisplay onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900">
      {/* Top Status Bar Simulator */}
      <div className="bg-emerald-600 h-1 w-full"></div>

      <main className="max-w-md mx-auto min-h-screen bg-white shadow-2xl overflow-hidden relative">
         <div className="h-full overflow-y-auto bg-gray-50">
           {renderContent()}
         </div>
         
         {/* Hide Bottom Nav on Admin Login screen */}
         {currentView !== ViewState.ADMIN && (
           <BottomNav 
             currentView={currentView} 
             onNavigate={setCurrentView} 
           />
         )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <DataProvider>
      <MainContent />
    </DataProvider>
  );
}