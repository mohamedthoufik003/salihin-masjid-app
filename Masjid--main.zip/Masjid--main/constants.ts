import { Announcement, MasjidEvent, PrayerTime } from "./types";

export const MASJID_NAME = "Salihin Masjid";
export const MASJID_LOCATION = "India";

// Sandbox Donation Details
export const DONATION_CONFIG = {
  upiId: "8939687453", // Provided number treated as UPI ID or proxy for it
  payeeName: "Salihin Masjid Trust",
  currency: "INR"
};

export const PRAYER_TIMES: PrayerTime[] = [
  { name: "Fajr", azan: "05:15 AM", iqamah: "05:45 AM" },
  { name: "Dhuhr", azan: "01:15 PM", iqamah: "01:45 PM" },
  { name: "Asr", azan: "04:30 PM", iqamah: "04:45 PM" },
  { name: "Maghrib", azan: "06:45 PM", iqamah: "06:50 PM" },
  { name: "Isha", azan: "08:15 PM", iqamah: "08:30 PM" },
  { name: "Jumu'ah", azan: "12:45 PM", iqamah: "01:30 PM" }
];

export const ANNOUNCEMENTS: Announcement[] = [
  {
    id: "1",
    title: "Ramadan Preparation",
    date: "2024-03-01",
    message: "The masjid cleaning drive will take place this Sunday after Fajr. Volunteers needed.",
    isUrgent: true
  },
  {
    id: "2",
    title: "Parking Notice",
    date: "2024-02-28",
    message: "Please do not park in front of the neighbors' driveways during Jumu'ah prayer.",
    isUrgent: false
  }
];

export const EVENTS: MasjidEvent[] = [
  {
    id: "101",
    title: "Weekly Jumu'ah Khutbah",
    date: "Every Friday",
    time: "01:00 PM",
    description: "Weekly sermon followed by congregational prayer.",
    location: "Main Hall",
    type: "JUMUAH"
  },
  {
    id: "102",
    title: "Tajweed Class for Kids",
    date: "Saturdays",
    time: "10:00 AM",
    description: "Learn proper Quranic recitation. Open for ages 7-12.",
    location: "Classroom B",
    type: "CLASS"
  },
  {
    id: "103",
    title: "Community Iftar Planning",
    date: "2024-03-10",
    time: "09:00 PM",
    description: "Meeting to discuss logistics for community Iftars.",
    location: "Basement Hall",
    type: "PROGRAM"
  }
];