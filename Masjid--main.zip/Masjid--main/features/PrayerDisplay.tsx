import React, { useEffect, useState } from 'react';
import { useData } from '../context/DataContext';
import { MASJID_NAME } from '../constants';
import { Clock, MapPin, Settings } from 'lucide-react';
import { ViewState } from '../types';

// Add props to navigate to Admin
interface PrayerDisplayProps {
  onNavigate: (view: ViewState) => void;
}

const PrayerDisplay: React.FC<PrayerDisplayProps> = ({ onNavigate }) => {
  const { prayerTimes } = useData(); // Use dynamic data
  const [currentTime, setCurrentTime] = useState<string>("");

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="p-4 space-y-6 pb-24 animate-fade-in">
      {/* Header Card */}
      <div className="bg-emerald-600 rounded-2xl p-6 text-white shadow-lg shadow-emerald-200 relative">
        <button 
          onClick={() => onNavigate(ViewState.ADMIN)}
          className="absolute top-4 right-4 text-emerald-200 hover:text-white transition-colors"
        >
          <Settings size={20} />
        </button>
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">{MASJID_NAME}</h1>
            <div className="flex items-center text-emerald-100 text-sm mt-1">
              <MapPin size={14} className="mr-1" />
              <span>India</span>
            </div>
          </div>
          <div className="text-right mr-6">
            <div className="text-xs text-emerald-200 uppercase tracking-wider">Current Time</div>
            <div className="text-xl font-mono font-bold">{currentTime}</div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-emerald-500/50">
           <p className="text-emerald-50 text-sm flex items-center">
             <Clock size={16} className="mr-2" />
             Next Iqamah: <span className="font-bold ml-1">Asr {prayerTimes.find(p => p.name === 'Asr')?.iqamah}</span>
           </p>
        </div>
      </div>

      {/* Prayer Times List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="grid grid-cols-3 bg-gray-50 p-3 text-xs font-semibold text-gray-500 uppercase tracking-wide border-b border-gray-100">
          <div>Prayer</div>
          <div className="text-center">Azan</div>
          <div className="text-right">Iqamah</div>
        </div>
        
        <div className="divide-y divide-gray-50">
          {prayerTimes.map((prayer, idx) => {
            const isNext = prayer.name === "Asr"; 
            
            return (
              <div 
                key={prayer.name} 
                className={`grid grid-cols-3 p-4 items-center transition-colors ${
                  isNext ? 'bg-emerald-50' : 'hover:bg-gray-50'
                }`}
              >
                <div className="font-bold text-gray-800 flex items-center">
                   {isNext && <div className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></div>}
                   {prayer.name}
                </div>
                <div className="text-center text-gray-600 font-mono text-sm">{prayer.azan}</div>
                <div className={`text-right font-mono text-sm font-bold ${isNext ? 'text-emerald-700' : 'text-slate-800'}`}>
                  {prayer.iqamah}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-amber-50 rounded-xl p-4 border border-amber-100">
        <p className="text-amber-800 text-sm italic text-center">
          "The most beloved of deeds to Allah are those that are most consistent, even if it is small."
        </p>
      </div>
    </div>
  );
};

export default PrayerDisplay;