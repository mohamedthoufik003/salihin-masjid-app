import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Lock, LogOut, Plus, Trash2, Save, X } from 'lucide-react';
import { Announcement, MasjidEvent, ViewState } from '../types';

interface AdminPortalProps {
  onNavigate: (view: ViewState) => void;
}

const AdminPortal: React.FC<AdminPortalProps> = ({ onNavigate }) => {
  const { 
    isAdmin, login, logout, 
    prayerTimes, updatePrayerTime,
    announcements, addAnnouncement, deleteAnnouncement,
    events, addEvent, deleteEvent
  } = useData();

  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'PRAYERS' | 'ANNOUNCEMENTS' | 'EVENTS'>('PRAYERS');

  // Form States
  const [newAnnouncement, setNewAnnouncement] = useState<Partial<Announcement>>({ title: '', message: '', isUrgent: false });
  const [newEvent, setNewEvent] = useState<Partial<MasjidEvent>>({ title: '', location: 'Main Hall', type: 'PROGRAM' });

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] p-6">
        <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm text-center">
          <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="text-emerald-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Admin Portal</h2>
          <p className="text-gray-500 mb-6 text-sm">Please enter your password to access admin controls.</p>
          
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 mb-4 focus:ring-2 focus:ring-emerald-500 outline-none"
            placeholder="Password"
          />
          
          <button
            onClick={() => {
              if (login(password)) {
                setPassword('');
              } else {
                alert('Invalid Password');
              }
            }}
            className="w-full bg-slate-800 text-white font-bold py-3 rounded-lg hover:bg-slate-900 transition-colors"
          >
            Login
          </button>
          
          <button 
            onClick={() => onNavigate(ViewState.HOME)}
            className="mt-4 text-gray-400 text-xs font-medium hover:text-gray-600"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const handleAddAnnouncement = () => {
    if (!newAnnouncement.title || !newAnnouncement.message) return;
    addAnnouncement({
      id: Date.now().toString(),
      date: new Date().toISOString(),
      title: newAnnouncement.title!,
      message: newAnnouncement.message!,
      isUrgent: newAnnouncement.isUrgent
    });
    setNewAnnouncement({ title: '', message: '', isUrgent: false });
  };

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date) return;
    addEvent({
      id: Date.now().toString(),
      title: newEvent.title!,
      date: newEvent.date!,
      time: newEvent.time || '12:00 PM',
      description: newEvent.description || '',
      location: newEvent.location || 'Main Hall',
      type: newEvent.type as any
    });
    setNewEvent({ title: '', location: 'Main Hall', type: 'PROGRAM', date: '', time: '', description: '' });
  };

  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      {/* Admin Header */}
      <div className="bg-slate-800 text-white p-6 sticky top-0 z-10 shadow-md">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <button onClick={logout} className="text-slate-300 hover:text-white flex items-center text-xs bg-slate-700 px-3 py-1 rounded-full">
            <LogOut size={12} className="mr-1" /> Logout
          </button>
        </div>
        
        {/* Tabs */}
        <div className="flex space-x-1 bg-slate-700/50 p-1 rounded-lg">
          {['PRAYERS', 'ANNOUNCEMENTS', 'EVENTS'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                activeTab === tab 
                  ? 'bg-white text-slate-900 shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        {/* PRAYERS TAB */}
        {activeTab === 'PRAYERS' && (
          <div className="space-y-4">
            <div className="bg-blue-50 text-blue-800 p-3 rounded-lg text-xs mb-2">
              Changes update immediately. Format example: "05:15 AM".
            </div>
            {prayerTimes.map((prayer, idx) => (
              <div key={prayer.name} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <div className="font-bold text-lg mb-2 text-slate-800">{prayer.name}</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-400 uppercase font-bold block mb-1">Azan</label>
                    <input
                      type="text"
                      value={prayer.azan}
                      onChange={(e) => updatePrayerTime(idx, 'azan', e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 uppercase font-bold block mb-1">Iqamah</label>
                    <input
                      type="text"
                      value={prayer.iqamah}
                      onChange={(e) => updatePrayerTime(idx, 'iqamah', e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-sm font-mono font-bold text-emerald-700"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ANNOUNCEMENTS TAB */}
        {activeTab === 'ANNOUNCEMENTS' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl shadow-sm border border-emerald-100">
              <h3 className="font-bold text-slate-800 mb-3 flex items-center"><Plus size={16} className="mr-2"/> New Announcement</h3>
              <input 
                className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm" 
                placeholder="Title"
                value={newAnnouncement.title}
                onChange={e => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
              />
              <textarea 
                className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm h-20" 
                placeholder="Message details..."
                value={newAnnouncement.message}
                onChange={e => setNewAnnouncement({...newAnnouncement, message: e.target.value})}
              />
              <div className="flex justify-between items-center">
                <label className="flex items-center text-sm text-gray-600">
                  <input 
                    type="checkbox" 
                    checked={newAnnouncement.isUrgent}
                    onChange={e => setNewAnnouncement({...newAnnouncement, isUrgent: e.target.checked})}
                    className="mr-2 accent-red-500" 
                  />
                  Mark as Urgent
                </label>
                <button 
                  onClick={handleAddAnnouncement}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md shadow-emerald-200"
                >
                  Post
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {announcements.map(item => (
                <div key={item.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-800">{item.title}</h4>
                    <p className="text-gray-500 text-xs mt-1 line-clamp-1">{item.message}</p>
                    <span className="text-[10px] text-gray-400 mt-2 block">{new Date(item.date).toLocaleDateString()}</span>
                  </div>
                  <button 
                    onClick={() => deleteAnnouncement(item.id)}
                    className="text-red-400 p-2 hover:bg-red-50 rounded-full"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EVENTS TAB */}
        {activeTab === 'EVENTS' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl shadow-sm border border-emerald-100">
              <h3 className="font-bold text-slate-800 mb-3 flex items-center"><Plus size={16} className="mr-2"/> New Event</h3>
              <input 
                className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm" 
                placeholder="Event Title"
                value={newEvent.title}
                onChange={e => setNewEvent({...newEvent, title: e.target.value})}
              />
              <div className="grid grid-cols-2 gap-3 mb-3">
                <input 
                  type="text"
                  className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm" 
                  placeholder="Date (e.g. Fridays)"
                  value={newEvent.date}
                  onChange={e => setNewEvent({...newEvent, date: e.target.value})}
                />
                <input 
                  type="text"
                  className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm" 
                  placeholder="Time (e.g. 1 PM)"
                  value={newEvent.time}
                  onChange={e => setNewEvent({...newEvent, time: e.target.value})}
                />
              </div>
               <select 
                  className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm"
                  value={newEvent.type}
                  onChange={e => setNewEvent({...newEvent, type: e.target.value as any})}
               >
                 <option value="JUMUAH">Jumu'ah</option>
                 <option value="CLASS">Class</option>
                 <option value="PROGRAM">Program</option>
               </select>
               <input 
                  className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm" 
                  placeholder="Location"
                  value={newEvent.location}
                  onChange={e => setNewEvent({...newEvent, location: e.target.value})}
                />
              <textarea 
                className="w-full mb-3 p-2 bg-gray-50 border border-gray-200 rounded-lg text-sm h-16" 
                placeholder="Description"
                value={newEvent.description}
                onChange={e => setNewEvent({...newEvent, description: e.target.value})}
              />
              <button 
                onClick={handleAddEvent}
                className="w-full bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-md shadow-emerald-200"
              >
                Add Event
              </button>
            </div>

            <div className="space-y-3">
              {events.map(item => (
                <div key={item.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-start">
                   <div>
                    <h4 className="font-bold text-slate-800">{item.title}</h4>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold uppercase">{item.type}</span>
                    <p className="text-gray-500 text-xs mt-1">{item.date} @ {item.time}</p>
                  </div>
                  <button 
                    onClick={() => deleteEvent(item.id)}
                    className="text-red-400 p-2 hover:bg-red-50 rounded-full"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPortal;