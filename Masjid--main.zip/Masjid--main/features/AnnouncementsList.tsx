import React from 'react';
import { useData } from '../context/DataContext';
import { Megaphone, AlertCircle } from 'lucide-react';

const AnnouncementsList: React.FC = () => {
  const { announcements } = useData();

  return (
    <div className="p-4 space-y-4 pb-24">
      <h2 className="text-xl font-bold text-slate-800 flex items-center mb-4">
        <Megaphone className="mr-2 text-emerald-600" size={24} />
        Announcements
      </h2>

      {announcements.length === 0 ? (
        <div className="text-center text-gray-500 py-10 bg-white rounded-xl">
          No new announcements.
        </div>
      ) : (
        announcements.map((item) => (
          <div 
            key={item.id} 
            className={`bg-white rounded-xl p-5 shadow-sm border-l-4 ${
              item.isUrgent ? 'border-l-red-500' : 'border-l-emerald-500'
            }`}
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-bold text-slate-800 text-lg">{item.title}</h3>
              {item.isUrgent && (
                <span className="bg-red-100 text-red-600 text-[10px] font-bold px-2 py-1 rounded-full flex items-center">
                  <AlertCircle size={10} className="mr-1" /> URGENT
                </span>
              )}
            </div>
            <p className="text-gray-600 text-sm leading-relaxed mb-3">
              {item.message}
            </p>
            <div className="text-xs text-gray-400 font-medium">
              Posted: {new Date(item.date).toLocaleDateString()}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default AnnouncementsList;