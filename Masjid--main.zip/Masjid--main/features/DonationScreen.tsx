import React, { useState } from 'react';
import { DONATION_CONFIG } from '../constants';
import { HeartHandshake, Copy, Check, ExternalLink } from 'lucide-react';

const DonationScreen: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState<string>("");

  // Construct UPI URL
  // Format: upi://pay?pa=<upi_id>&pn=<payee_name>&am=<amount>&cu=<currency>
  const getUpiUrl = () => {
    let url = `upi://pay?pa=${DONATION_CONFIG.upiId}&pn=${encodeURIComponent(DONATION_CONFIG.payeeName)}&cu=${DONATION_CONFIG.currency}`;
    if (amount) {
      url += `&am=${amount}`;
    }
    return url;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(DONATION_CONFIG.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const quickAmounts = ["100", "500", "1000", "5000"];

  return (
    <div className="p-4 space-y-6 pb-24">
      <h2 className="text-xl font-bold text-slate-800 flex items-center">
        <HeartHandshake className="mr-2 text-emerald-600" size={24} />
        Donate
      </h2>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
        <p className="text-gray-600 text-sm mb-4">
          Support <strong>{DONATION_CONFIG.payeeName}</strong> securely via UPI.
        </p>

        {/* Dynamic QR Code based on the details */}
        <div className="bg-white p-2 border border-gray-200 rounded-lg inline-block mb-4">
           <img 
             src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(getUpiUrl())}`}
             alt="UPI QR Code"
             className="w-40 h-40"
           />
        </div>

        <div className="flex items-center justify-center space-x-2 bg-gray-50 p-3 rounded-lg mb-6">
          <span className="font-mono text-slate-800 font-medium">{DONATION_CONFIG.upiId}</span>
          <button 
            onClick={handleCopy}
            className="text-gray-400 hover:text-emerald-600 transition-colors"
          >
            {copied ? <Check size={16} className="text-emerald-600" /> : <Copy size={16} />}
          </button>
        </div>

        {/* Amount Input */}
        <div className="text-left mb-6">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Enter Amount (INR)</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
            <input 
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="w-full pl-8 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-lg text-slate-800"
            />
          </div>
          <div className="flex space-x-2 mt-3">
             {quickAmounts.map(amt => (
               <button
                 key={amt}
                 onClick={() => setAmount(amt)}
                 className="flex-1 py-1 text-xs font-semibold bg-emerald-50 text-emerald-700 rounded border border-emerald-100 hover:bg-emerald-100"
               >
                 ₹{amt}
               </button>
             ))}
          </div>
        </div>

        <a 
          href={getUpiUrl()}
          className="block w-full bg-emerald-600 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-emerald-200 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center"
        >
          Pay via UPI App <ExternalLink size={16} className="ml-2" />
        </a>
        
        <p className="text-[10px] text-gray-400 mt-4">
          This uses the UPI Sandbox logic. In a real device, this button opens GPay, PhonePe, or Paytm installed on your phone.
        </p>
      </div>
    </div>
  );
};

export default DonationScreen;