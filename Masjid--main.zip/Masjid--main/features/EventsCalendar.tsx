import React from 'react';
import { useData } from '../context/DataContext';
import { Calendar, Clock, MapPin } from 'lucide-react';

const EventsCalendar: React.FC = () => {
  const { events } = useData();

  return (
    <div className="p-4 space-y-4 pb-24">
      <h2 className="text-xl font-bold text-slate-800 flex items-center mb-4">
        <Calendar className="mr-2 text-emerald-600" size={24} />
        Upcoming Events
      </h2>

      {events.length === 0 ? (
        <div className="text-center text-gray-500 py-10 bg-white rounded-xl">
           No upcoming events scheduled.
        </div>
      ) : (
        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100">
              <div className="bg-emerald-50 px-4 py-2 border-b border-emerald-100 flex justify-between items-center">
                <span className="text-emerald-800 font-bold text-sm uppercase tracking-wide">
                  {event.type}
                </span>
                <span className="text-emerald-600 text-xs font-semibold">
                  {event.date}
                </span>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg text-slate-800 mb-2">{event.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{event.description}</p>
                
                <div className="flex items-center space-x-4 text-xs text-gray-500">
                  <div className="flex items-center">
                    <Clock size={14} className="mr-1 text-gray-400" />
                    {event.time}
                  </div>
                  <div className="flex items-center">
                    <MapPin size={14} className="mr-1 text-gray-400" />
                    {event.location}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default EventsCalendar;