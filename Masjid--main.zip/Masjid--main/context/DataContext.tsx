import React, { createContext, useContext, useState, useEffect } from 'react';
import { Announcement, MasjidEvent, PrayerTime } from '../types';
import { PRAYER_TIMES as DEFAULT_PRAYER_TIMES, ANNOUNCEMENTS as DEFAULT_ANNOUNCEMENTS, EVENTS as DEFAULT_EVENTS } from '../constants';

interface DataContextType {
  prayerTimes: PrayerTime[];
  announcements: Announcement[];
  events: MasjidEvent[];
  updatePrayerTime: (index: number, field: 'azan' | 'iqamah', value: string) => void;
  addAnnouncement: (announcement: Announcement) => void;
  deleteAnnouncement: (id: string) => void;
  addEvent: (event: MasjidEvent) => void;
  deleteEvent: (id: string) => void;
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state from LocalStorage if available, otherwise use defaults
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime[]>(() => {
    const saved = localStorage.getItem('prayerTimes');
    return saved ? JSON.parse(saved) : DEFAULT_PRAYER_TIMES;
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = localStorage.getItem('announcements');
    return saved ? JSON.parse(saved) : DEFAULT_ANNOUNCEMENTS;
  });

  const [events, setEvents] = useState<MasjidEvent[]>(() => {
    const saved = localStorage.getItem('events');
    return saved ? JSON.parse(saved) : DEFAULT_EVENTS;
  });

  const [isAdmin, setIsAdmin] = useState(false);

  // Persistence Effects
  useEffect(() => localStorage.setItem('prayerTimes', JSON.stringify(prayerTimes)), [prayerTimes]);
  useEffect(() => localStorage.setItem('announcements', JSON.stringify(announcements)), [announcements]);
  useEffect(() => localStorage.setItem('events', JSON.stringify(events)), [events]);

  // Actions
  const updatePrayerTime = (index: number, field: 'azan' | 'iqamah', value: string) => {
    const newTimes = [...prayerTimes];
    newTimes[index] = { ...newTimes[index], [field]: value };
    setPrayerTimes(newTimes);
  };

  const addAnnouncement = (item: Announcement) => setAnnouncements([item, ...announcements]);
  const deleteAnnouncement = (id: string) => setAnnouncements(announcements.filter(a => a.id !== id));

  const addEvent = (item: MasjidEvent) => setEvents([item, ...events]);
  const deleteEvent = (id: string) => setEvents(events.filter(e => e.id !== id));

  const login = (password: string) => {
    if (password === 'admin') { // Simple hardcoded check
      setIsAdmin(true);
      return true;
    }
    return false;
  };

  const logout = () => setIsAdmin(false);

  return (
    <DataContext.Provider value={{
      prayerTimes, announcements, events,
      updatePrayerTime, addAnnouncement, deleteAnnouncement,
      addEvent, deleteEvent,
      isAdmin, login, logout
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within a DataProvider');
  return context;
};