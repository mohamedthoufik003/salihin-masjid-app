export enum ViewState {
  HOME = 'HOME',
  ANNOUNCEMENTS = 'ANNOUNCEMENTS',
  EVENTS = 'EVENTS',
  DONATE = 'DONATE',
  ADMIN = 'ADMIN'
}

export interface PrayerTime {
  name: string;
  azan: string;
  iqamah: string;
  isNext?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  message: string;
  isUrgent?: boolean;
}

export interface MasjidEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  description: string;
  location: string;
  type: 'JUMUAH' | 'CLASS' | 'PROGRAM';
}

export interface DonationDetails {
  upiId: string;
  payeeName: string;
  currency: string;
}